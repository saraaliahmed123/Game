import java.util.ArrayList;	  			        	      	  		
public class Player	  			        	      	  		
{	  			        	      	  		
  private Hand hand;	  			        	      	  		
	  			        	      	  		
  public void setHand(Hand h)	  			        	      	  		
  {	  			        	      	  		
    this.hand = h;	  			        	      	  		
  }	  			        	      	  		
	  			        	      	  		
  public Hand getHand()	  			        	      	  		
  {	  			        	      	  		
    return this.hand;	  			        	      	  		
  }	  			        	      	  		
	  			        	      	  		
}